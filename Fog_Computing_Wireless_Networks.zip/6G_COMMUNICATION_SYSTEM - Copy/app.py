from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
import pandas as pd
import numpy as np
import joblib
import random
import networkx as nx
from datetime import datetime
import json
import plotly.graph_objs as go
import plotly.utils
import base64
from io import BytesIO
import matplotlib.pyplot as plt
import seaborn as sns
import os
import wave
import audioop
import cv2
from werkzeug.utils import secure_filename
import time

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max file size

# Create upload folder if not exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Load trained models
print("Loading trained models...")
try:
    reg_model = joblib.load('cluster_efficiency_regression_model.pkl')
    clf_model = joblib.load('cluster_head_classifier_model.pkl')
    scaler = joblib.load('feature_scaler.pkl')
    feature_columns = joblib.load('feature_columns.pkl')
    attack_model = joblib.load('attack_prediction_best_model.pkl')
    attack_encoder = joblib.load('attack_label_encoder.pkl')
    attack_scaler = joblib.load('attack_feature_scaler.pkl')
    attack_features = joblib.load('attack_features_list.pkl')
    
    # Load D2D models
    power_model = joblib.load('power_allocation_model.pkl')
    power_scaler = joblib.load('scaler1.pkl')
    le_app = joblib.load('app_encoder.pkl')
    le_user = joblib.load('user_encoder.pkl')
    
    resource_model = joblib.load('resource_allocation_model.pkl')
    resource_scaler = joblib.load('scaler.pkl')
    print("✓ All models loaded successfully!")
except Exception as e:
    print(f"Warning: Could not load all models: {e}")
    reg_model = clf_model = scaler = attack_model = power_model = resource_model = None

class ClusterSimulator:
    def __init__(self):
        self.graph = None
        self.nodes = []
        self.edges = []
        
    def generate_network(self, num_nodes=15):
        """Generate random network topology"""
        nodes = []
        for i in range(num_nodes):
            node = {
                'id': i,
                'name': f'Node_{i}',
                'efficiency': random.uniform(0.5, 0.95),
                'battery': random.uniform(50, 100),
                'x': random.uniform(10, 90),
                'y': random.uniform(10, 90),
                'is_ch': False
            }
            nodes.append(node)
        
        # Select top 30% as cluster heads based on efficiency
        sorted_nodes = sorted(nodes, key=lambda x: x['efficiency'], reverse=True)
        num_ch = max(3, int(num_nodes * 0.3))
        for i in range(num_ch):
            sorted_nodes[i]['is_ch'] = True
        
        # Create edges
        edges = []
        for node in nodes:
            if not node['is_ch']:
                ch_nodes = [n for n in nodes if n['is_ch']]
                nearest_ch = min(ch_nodes, key=lambda ch: np.hypot(ch['x'] - node['x'], ch['y'] - node['y']))
                edges.append({
                    'source': node['id'],
                    'target': nearest_ch['id'],
                    'weight': np.hypot(nearest_ch['x'] - node['x'], nearest_ch['y'] - node['y']),
                    'latency': random.uniform(5, 20),
                    'bandwidth': random.uniform(50, 100)
                })
        
        ch_nodes = [n for n in nodes if n['is_ch']]
        for i in range(len(ch_nodes)):
            for j in range(i+1, len(ch_nodes)):
                edges.append({
                    'source': ch_nodes[i]['id'],
                    'target': ch_nodes[j]['id'],
                    'weight': np.hypot(ch_nodes[j]['x'] - ch_nodes[i]['x'], ch_nodes[j]['y'] - ch_nodes[i]['y']),
                    'latency': random.uniform(5, 15),
                    'bandwidth': random.uniform(60, 100)
                })
        
        return nodes, edges
    
    def calculate_shortest_path(self, nodes, edges, source, target, algorithm='dijkstra'):
        """Calculate shortest path using selected algorithm"""
        G = nx.Graph()
        
        for node in nodes:
            G.add_node(node['id'], pos=(node['x'], node['y']))
        
        for edge in edges:
            G.add_edge(edge['source'], edge['target'], weight=edge['weight'])
        
        try:
            if algorithm == 'dijkstra':
                path = nx.dijkstra_path(G, source, target, weight='weight')
                path_length = nx.dijkstra_path_length(G, source, target, weight='weight')
            elif algorithm == 'astar':
                pos = nx.get_node_attributes(G, 'pos')
                def heuristic(u, v):
                    return np.hypot(pos[u][0] - pos[v][0], pos[u][1] - pos[v][1])
                path = nx.astar_path(G, source, target, heuristic=heuristic, weight='weight')
                path_length = nx.astar_path_length(G, source, target, heuristic=heuristic, weight='weight')
            elif algorithm == 'bellman_ford':
                path = nx.bellman_ford_path(G, source, target, weight='weight')
                path_length = nx.bellman_ford_path_length(G, source, target, weight='weight')
            else:
                path = nx.dijkstra_path(G, source, target, weight='weight')
                path_length = nx.dijkstra_path_length(G, source, target, weight='weight')
            
            total_latency = 0
            min_bandwidth = float('inf')
            
            for i in range(len(path)-1):
                for edge in edges:
                    if (edge['source'] == path[i] and edge['target'] == path[i+1]) or \
                       (edge['source'] == path[i+1] and edge['target'] == path[i]):
                        total_latency += edge.get('latency', 10)
                        min_bandwidth = min(min_bandwidth, edge.get('bandwidth', 100))
                        break
            
            return {
                'path': path,
                'length': path_length,
                'latency': total_latency,
                'bandwidth': min_bandwidth if min_bandwidth != float('inf') else 100,
                'hops': len(path) - 1
            }
        except:
            return None

simulator = ClusterSimulator()

def analyze_media_performance(file_path, file_type):
    """Analyze media file and predict resource requirements"""
    try:
        file_size = os.path.getsize(file_path) / (1024 * 1024)  # Size in MB
        duration = 0
        required_bandwidth = 0
        
        if file_type == 'audio':
            try:
                with wave.open(file_path, 'rb') as wav_file:
                    frames = wav_file.getnframes()
                    rate = wav_file.getframerate()
                    duration = frames / float(rate) if rate > 0 else 0
                    # Calculate bitrate in Mbps
                    bitrate = (file_size * 8) / duration if duration > 0 else 1
                    required_bandwidth = bitrate * 1.2  # 20% overhead
            except:
                # If wave fails, estimate based on file size
                duration = file_size * 60  # Rough estimate: 1MB per minute for audio
                required_bandwidth = (file_size * 8) / duration if duration > 0 else 5
        else:  # video
            try:
                import cv2
                cap = cv2.VideoCapture(file_path)
                fps = cap.get(cv2.CAP_PROP_FPS)
                frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                duration = frame_count / fps if fps > 0 else 0
                cap.release()
                
                # Calculate bitrate in Mbps
                bitrate = (file_size * 8) / duration if duration > 0 else 10
                required_bandwidth = bitrate * 1.3  # 30% overhead for video
            except:
                # If OpenCV fails, estimate based on file size
                duration = file_size * 30  # Rough estimate: 1MB per 30 seconds for video
                required_bandwidth = (file_size * 8) / duration if duration > 0 else 10
        
        # Ensure values are reasonable
        required_bandwidth = max(1, min(100, required_bandwidth))
        duration = max(1, duration)
        file_size = max(0.01, file_size)
        
        # Calculate predicted resource allocation using ML model
        if resource_model is not None:
            signal_strength = -65 + np.random.uniform(-10, 10)
            latency = 20 + np.random.uniform(-5, 15)
            allocated_bandwidth = required_bandwidth * 1.5
            
            user_input = np.array([[required_bandwidth, allocated_bandwidth, signal_strength, latency]])
            scaled_input = resource_scaler.transform(user_input)
            predicted_resource = resource_model.predict(scaled_input)[0]
            predicted_resource = float(max(0, min(100, predicted_resource)))  # Convert to Python float
        else:
            predicted_resource = float(65 + np.random.uniform(-15, 15))
        
        # Calculate conventional method performance (baseline)
        conventional_resource = required_bandwidth / 10 * 100
        conventional_resource = float(max(0, min(100, conventional_resource)))
        
        # Calculate improvement
        if conventional_resource > 0:
            improvement = ((conventional_resource - predicted_resource) / conventional_resource) * 100
        else:
            improvement = 0
        
        improvement = float(improvement)
        
        return {
            'success': True,
            'file_name': os.path.basename(file_path),
            'file_type': file_type,
            'file_size_mb': round(float(file_size), 2),
            'duration_sec': round(float(duration), 2),
            'required_bandwidth_mbps': round(float(required_bandwidth), 2),
            'predicted_resource_allocation': round(float(predicted_resource), 2),
            'conventional_resource_allocation': round(float(conventional_resource), 2),
            'improvement_percentage': round(float(improvement), 2),
            'is_better': bool(improvement > 0),  # Convert to Python bool
            'recommendation': 'Our ML model provides better resource efficiency!' if improvement > 0 else 'Conventional method may be sufficient'
        }
    except Exception as e:
        return {'success': False, 'error': str(e)}

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/cluster-simulation')
def cluster_simulation():
    return render_template('cluster_simulation.html')

@app.route('/attack-prediction')
def attack_prediction():
    return render_template('attack_prediction.html')

@app.route('/d2d-power')
def d2d_power():
    return render_template('d2d_power.html')

@app.route('/d2d-resource')
def d2d_resource():
    return render_template('d2d_resource.html')

@app.route('/performance-analysis')
def performance_analysis():
    return render_template('performance_analysis.html')

# API Endpoints
@app.route('/api/generate-network', methods=['POST'])
def generate_network():
    data = request.json
    num_nodes = data.get('num_nodes', 15)
    nodes, edges = simulator.generate_network(num_nodes)
    return jsonify({'nodes': nodes, 'edges': edges})

@app.route('/api/shortest-path', methods=['POST'])
def shortest_path():
    data = request.json
    nodes = data.get('nodes')
    edges = data.get('edges')
    source = data.get('source')
    target = data.get('target')
    algorithm = data.get('algorithm', 'dijkstra')
    
    result = simulator.calculate_shortest_path(nodes, edges, source, target, algorithm)
    
    if result:
        path_nodes = []
        for node_id in result['path']:
            for node in nodes:
                if node['id'] == node_id:
                    path_nodes.append({'id': node_id, 'x': node['x'], 'y': node['y']})
                    break
        
        result['path_nodes'] = path_nodes
        return jsonify(result)
    else:
        return jsonify({'error': 'Path not found'}), 404

@app.route('/api/simulation-data', methods=['GET'])
def simulation_data():
    num_nodes = random.randint(10, 20)
    nodes, edges = simulator.generate_network(num_nodes)
    
    total_bandwidth = sum(edge.get('bandwidth', 0) for edge in edges)
    avg_latency = np.mean([edge.get('latency', 0) for edge in edges]) if edges else 0
    active_flows = random.randint(5, 20)
    packet_loss = random.uniform(0.1, 2.0)
    
    return jsonify({
        'nodes': nodes,
        'edges': edges,
        'metrics': {
            'total_bandwidth': f"{total_bandwidth:.0f} Mbps",
            'avg_latency': f"{avg_latency:.1f} ms",
            'active_flows': active_flows,
            'packet_loss': f"{packet_loss:.2f}%",
            'throughput': f"{random.uniform(80, 95):.1f}%"
        }
    })

@app.route('/api/predict-attack', methods=['POST'])
def predict_attack():
    try:
        data = request.json
        
        node_data = {
            'Time': data.get('Time', 50),
            'Is_CH': data.get('Is_CH', 0),
            'Dist_To_CH': data.get('Dist_To_CH', 50),
            'ADV_S': data.get('ADV_S', 5),
            'ADV_R': data.get('ADV_R', 5),
            'JOIN_S': data.get('JOIN_S', 3),
            'JOIN_R': data.get('JOIN_R', 3),
            'SCH_S': data.get('SCH_S', 2),
            'SCH_R': data.get('SCH_R', 2),
            'Rank': data.get('Rank', 10),
            'DATA_S': data.get('DATA_S', 100),
            'DATA_R': data.get('DATA_R', 95),
            'Data_Sent_To_BS': data.get('Data_Sent_To_BS', 100),
            'dist_CH_To_BS': data.get('dist_CH_To_BS', 100),
            'send_code': data.get('send_code', 2),
            'Expaned Energy': data.get('Expaned Energy', 0.07)
        }
        
        df = pd.DataFrame([node_data])
        df['data_rate'] = df['DATA_S'] / (df['Time'] + 1)
        df['adv_to_join_ratio'] = df['ADV_S'] / (df['JOIN_S'] + 1)
        df['sch_efficiency'] = df['SCH_S'] / (df['SCH_R'] + 1)
        df['communication_overhead'] = (df['ADV_S'] + df['JOIN_S'] + df['SCH_S']) / (df['Time'] + 1)
        df['energy_per_data'] = df['Expaned Energy'] / (df['Data_Sent_To_BS'] + 1)
        df['energy_efficiency'] = df['Data_Sent_To_BS'] / (df['Expaned Energy'] + 0.001)
        df['relative_distance'] = df['Dist_To_CH'] / (df['dist_CH_To_BS'] + 1)
        df['network_density'] = 1 / (df['Dist_To_CH'] + 0.001)
        df['control_packet_ratio'] = (df['ADV_S'] + df['JOIN_S']) / (df['DATA_S'] + 1)
        df['response_latency'] = df['JOIN_R'] / (df['JOIN_S'] + 1)
        df['packet_drop_rate'] = (df['ADV_S'] - df['ADV_R']) / (df['ADV_S'] + 1)
        df['join_success_rate'] = df['JOIN_R'] / (df['JOIN_S'] + 1)
        
        features = df[attack_features]
        features_scaled = attack_scaler.transform(features)
        
        prediction = attack_model.predict(features_scaled)[0]
        probabilities = attack_model.predict_proba(features_scaled)[0]
        
        attack_type = attack_encoder.inverse_transform([prediction])[0]
        confidence = probabilities[prediction]
        
        all_probs = dict(zip(attack_encoder.classes_, probabilities))
        
        return jsonify({
            'predicted_attack': attack_type,
            'confidence': float(confidence),
            'probabilities': all_probs
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/predict-power', methods=['POST'])
def predict_power():
    try:
        data = request.json
        
        user_id = data.get('user_id')
        application_type = data.get('application_type')
        signal_strength = float(data.get('signal_strength'))
        latency = float(data.get('latency'))
        required_bandwidth = float(data.get('required_bandwidth'))
        allocated_bandwidth = float(data.get('allocated_bandwidth'))
        resource_allocation = float(data.get('resource_allocation'))
        
        user_id_encoded = le_user.transform([user_id])[0]
        app_type_encoded = le_app.transform([application_type])[0]
        
        input_data = np.array([[user_id_encoded, app_type_encoded, signal_strength,
                                latency, required_bandwidth, allocated_bandwidth, resource_allocation]])
        
        input_scaled = power_scaler.transform(input_data)
        predicted_power = power_model.predict(input_scaled)[0]
        predicted_power = max(0, min(150, predicted_power))
        
        if predicted_power < 30:
            efficiency = "Excellent - Very Low Power Consumption"
            color = "success"
        elif predicted_power < 60:
            efficiency = "Good - Optimal Power Usage"
            color = "info"
        elif predicted_power < 85:
            efficiency = "Fair - Moderate Power Consumption"
            color = "warning"
        else:
            efficiency = "Poor - High Power Consumption"
            color = "danger"
        
        return jsonify({
            'success': True,
            'predicted_power': float(predicted_power),
            'efficiency_level': efficiency,
            'efficiency_color': color,
            'message': f'Predicted power allocation: {predicted_power:.2f} units'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/predict-resource', methods=['POST'])
def predict_resource():
    try:
        data = request.json
        
        required_bandwidth = float(data.get('required_bandwidth'))
        allocated_bandwidth = float(data.get('allocated_bandwidth'))
        signal_strength = float(data.get('signal_strength'))
        latency = float(data.get('latency'))
        
        user_input = np.array([[required_bandwidth, allocated_bandwidth, signal_strength, latency]])
        scaled_input = resource_scaler.transform(user_input)
        predicted_resource = resource_model.predict(scaled_input)[0]
        predicted_resource = max(0, min(100, predicted_resource))
        
        if predicted_resource < 30:
            utilization_level = "Low - Underutilized"
            color = "secondary"
            recommendation = "Consider reducing allocated bandwidth to improve efficiency."
        elif predicted_resource < 60:
            utilization_level = "Moderate - Balanced"
            color = "info"
            recommendation = "Resource utilization is balanced. Good allocation strategy."
        elif predicted_resource < 85:
            utilization_level = "High - Efficient"
            color = "success"
            recommendation = "Optimal resource utilization. Excellent allocation!"
        else:
            utilization_level = "Critical - Near Capacity"
            color = "danger"
            recommendation = "Resource near capacity. Consider increasing bandwidth allocation."
        
        return jsonify({
            'success': True,
            'predicted_resource': float(predicted_resource),
            'utilization_level': utilization_level,
            'utilization_color': color,
            'utilization_percent': float(predicted_resource),
            'recommendation': recommendation,
            'message': f'Predicted resource allocation: {predicted_resource:.2f}%'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/analyze-media', methods=['POST'])
def analyze_media():
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'error': 'No file selected'}), 400
        
        # Check file size (max 100MB)
        file.seek(0, 2)
        file_size_bytes = file.tell()
        file.seek(0)
        
        if file_size_bytes > 100 * 1024 * 1024:
            return jsonify({'success': False, 'error': 'File too large. Maximum size is 100MB'}), 400
        
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Check file extension
        file_ext = filename.split('.')[-1].lower()
        audio_extensions = ['wav', 'mp3', 'ogg', 'm4a', 'flac']
        video_extensions = ['mp4', 'avi', 'mov', 'mkv', 'webm']
        
        if file_ext in audio_extensions:
            file_type = 'audio'
        elif file_ext in video_extensions:
            file_type = 'video'
        else:
            os.remove(filepath)
            return jsonify({'success': False, 'error': f'Unsupported file type: {file_ext}. Please upload audio or video files.'}), 400
        
        # Analyze the media file
        result = analyze_media_performance(filepath, file_type)
        
        # Clean up - remove the uploaded file
        try:
            os.remove(filepath)
        except:
            pass
        
        # Ensure all values are JSON serializable
        if result.get('success'):
            # Convert any numpy types to Python native types
            for key in ['file_size_mb', 'duration_sec', 'required_bandwidth_mbps', 
                       'predicted_resource_allocation', 'conventional_resource_allocation', 
                       'improvement_percentage']:
                if key in result:
                    result[key] = float(result[key])
            
            result['is_better'] = bool(result.get('is_better', False))
        
        return jsonify(result)
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/d2d-options', methods=['GET'])
def get_d2d_options():
    try:
        app_types = le_app.classes_.tolist()
        user_ids = le_user.classes_.tolist()
        
        return jsonify({
            'success': True,
            'application_types': app_types,
            'user_ids': user_ids
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)